package com.example.fcstade

object Utils {
    var IDPOSITION : String = ""

}