package com.example.fcstade.models.Stadium

data class StadiumResponse(val code:Int?,val meta:String,val data:ListStItem)
