package com.example.fcstade.models.users

data class UserList(val data: List<User>)
