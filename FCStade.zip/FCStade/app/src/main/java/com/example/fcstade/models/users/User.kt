package com.example.fcstade.models.users

data class User(
    val firstName: String,
    val lastName: String,
    val age: String,
    val username: String,
    val password: String,
    val email: String
)