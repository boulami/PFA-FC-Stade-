package com.example.fcstade.models.users

data class UserResponse(val code:Int?,val meta:String?,val data: User?)
