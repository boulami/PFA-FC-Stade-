package com.example.fcstade.models.reservation




data class ReservationResponse(val code:Int?,val meta:String?,val data: Reservation?)
