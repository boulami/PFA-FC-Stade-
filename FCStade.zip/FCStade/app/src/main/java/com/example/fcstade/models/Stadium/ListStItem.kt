package com.example.fcstade.models.Stadium

data class ListStItem(
    val id:String,
    val address: String,
    val name: String
)