package com.example.fcstade.models.reservation

class ReservationList:ArrayList<Reservation>()
